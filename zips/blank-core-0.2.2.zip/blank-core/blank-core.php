<?php
/**
 * Plugin Name:       Blank Core
 * Description:       Socle Blank Light : espace propriétaire en façade (/tsuki), centre de contrôle des extensions Blank, rôles d'équipe, réglages du site, messages de contact.
 * Version:           0.2.2
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            COOXAPPS
 * License:           GPL-2.0-or-later
 * Text Domain:       blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BLANK_CORE_VERSION', '0.2.2' );
define( 'BLANK_CORE_FILE', __FILE__ );
define( 'BLANK_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'BLANK_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once BLANK_CORE_DIR . 'includes/roles.php';
require_once BLANK_CORE_DIR . 'includes/access.php';
require_once BLANK_CORE_DIR . 'includes/settings.php';
require_once BLANK_CORE_DIR . 'includes/contact.php';
require_once BLANK_CORE_DIR . 'includes/mail.php';
require_once BLANK_CORE_DIR . 'includes/account.php';
require_once BLANK_CORE_DIR . 'includes/orders.php';
require_once BLANK_CORE_DIR . 'includes/space.php';
require_once BLANK_CORE_DIR . 'includes/extensions.php';
require_once BLANK_CORE_DIR . 'includes/install.php';

register_activation_hook( __FILE__, 'blank_core_activate' );
register_deactivation_hook( __FILE__, 'blank_core_deactivate' );

add_action( 'plugins_loaded', 'blank_core_boot' );

/**
 * Wires every part of the socle.
 */
function blank_core_boot() {
	blank_access_init();
	blank_settings_init();
	blank_contact_init();
	blank_account_init();
	blank_orders_init();
	blank_space_init();
	blank_extensions_init();
	add_action( 'init', 'blank_core_maybe_upgrade', 5 );
}
