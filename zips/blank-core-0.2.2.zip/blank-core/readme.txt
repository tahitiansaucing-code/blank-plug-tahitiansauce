=== Blank Core ===
Version: 0.2.2
Requires at least: 6.5
Requires PHP: 7.4

Socle Blank Light pour WordPress : espace propriétaire en façade (/tsuki), rôles d'équipe, réglages du site, messages de contact, coque d'e-mails.

== Pour les autres extensions Blank ==
* Menus de l'espace : filtre `blank_staff_menus` (key, label, render, order).
* Droits : `blank_staff_can( $user_id, $area )`, filtre `blank_staff_allowed` (true, false ou null ; tout refus l'emporte ; le super-admin n'est jamais bloqué).
* Onglets de Mon compte (WooCommerce) : filtre `blank_account_tabs`.
* E-mails : `blank_send_mail()`, filtre `blank_mails`.
* Dépendances : en-tête `Requires Plugins: blank-core, woocommerce` dans le fichier principal (lu par WordPress et par le centre de contrôle) ; `blank_require_or_die()` en secours à l'activation.
* Menus réservés au super-admin : `'super' => true` dans `blank_staff_menus`.
* Événement : action `blank_contact_message`.
