<?php
/**
 * Activation, upgrade, deactivation. Safe to run again.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates or updates tables, roles and default options.
 */
function blank_core_install() {
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( blank_contact_schema() );
	blank_install_roles();
	add_option( 'blank_settings', blank_setting_defaults(), '', false );
	add_option( 'blank_theme', BLANK_DEFAULT_THEME );
	update_option( 'blank_core_version', BLANK_CORE_VERSION, false );
}

/**
 * Activation hook.
 */
function blank_core_activate() {
	blank_core_install();
	blank_space_rewrite();
	flush_rewrite_rules( false );
}

/**
 * Deactivation hook: rules only, data stays.
 */
function blank_core_deactivate() {
	flush_rewrite_rules( false );
}

/**
 * Runs the install again after an update of the plugin files.
 */
function blank_core_maybe_upgrade() {
	if ( get_option( 'blank_core_version' ) !== BLANK_CORE_VERSION ) {
		blank_core_install();
		blank_space_rewrite();
		flush_rewrite_rules( false );
	}
}
