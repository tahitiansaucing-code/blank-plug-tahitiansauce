<?php
/**
 * Mon compte: plugins add tabs through `blank_account_tabs`, shown in the WooCommerce account page.
 *
 * Each tab: [ 'key' => 'devis', 'label' => 'Devis', 'render' => callable( int $user_id ) ].
 * The render callable receives the logged-in user id and must only show that user's objects.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks of Mon compte.
 */
function blank_account_init() {
	add_action( 'init', 'blank_account_endpoints' );
	add_filter( 'woocommerce_account_menu_items', 'blank_account_menu' );
	add_filter( 'woocommerce_get_query_vars', 'blank_account_query_vars' );
}

/**
 * Valid tabs from running plugins.
 *
 * @return array<string,array{key:string,label:string,render:callable}>
 */
function blank_account_tabs() {
	$tabs  = apply_filters( 'blank_account_tabs', array() );
	$valid = array();
	foreach ( is_array( $tabs ) ? $tabs : array() as $tab ) {
		if ( ! is_array( $tab ) || empty( $tab['key'] ) || empty( $tab['label'] ) || empty( $tab['render'] ) || ! is_callable( $tab['render'] ) ) {
			continue;
		}
		$key           = sanitize_key( $tab['key'] );
		$valid[ $key ] = array(
			'key'    => $key,
			'label'  => (string) $tab['label'],
			'render' => $tab['render'],
		);
	}
	return $valid;
}

/**
 * Registers one account endpoint per tab.
 */
function blank_account_endpoints() {
	foreach ( blank_account_tabs() as $key => $tab ) {
		add_rewrite_endpoint( $key, EP_ROOT | EP_PAGES );
		add_action(
			'woocommerce_account_' . $key . '_endpoint',
			static function () use ( $tab ) {
				$user_id = get_current_user_id();
				if ( $user_id ) {
					call_user_func( $tab['render'], $user_id );
				}
			}
		);
	}
}

/**
 * Lets WooCommerce know the endpoints.
 *
 * @param array $vars Query vars.
 * @return array
 */
function blank_account_query_vars( $vars ) {
	foreach ( array_keys( blank_account_tabs() ) as $key ) {
		$vars[ $key ] = $key;
	}
	return $vars;
}

/**
 * Adds the tabs before "Déconnexion".
 *
 * @param array $items Menu items.
 * @return array
 */
function blank_account_menu( $items ) {
	$logout = isset( $items['customer-logout'] ) ? $items['customer-logout'] : null;
	unset( $items['customer-logout'] );
	foreach ( blank_account_tabs() as $key => $tab ) {
		$items[ $key ] = $tab['label'];
	}
	if ( null !== $logout ) {
		$items['customer-logout'] = $logout;
	}
	return $items;
}
