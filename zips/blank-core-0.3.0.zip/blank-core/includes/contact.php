<?php
/**
 * Contact messages: stored in a table, the contact address never leaves the server.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Messages a visitor may send per hour. */
const BLANK_CONTACT_PER_HOUR = 5;

/**
 * Hooks of the contact form.
 */
function blank_contact_init() {
	add_action( 'rest_api_init', 'blank_contact_routes' );
	add_shortcode( 'blank_contact', 'blank_contact_shortcode' );
}

/**
 * Table name.
 *
 * @return string
 */
function blank_contact_table() {
	global $wpdb;
	return $wpdb->prefix . 'blank_contact_messages';
}

/**
 * Table schema for dbDelta.
 *
 * @return string
 */
function blank_contact_schema() {
	global $wpdb;
	$table   = blank_contact_table();
	$charset = $wpdb->get_charset_collate();
	return "CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(120) NOT NULL,
  email varchar(200) NOT NULL,
  phone varchar(40) NOT NULL DEFAULT '',
  message text NOT NULL,
  user_id bigint(20) unsigned NULL,
  is_read tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY created_at (created_at)
) {$charset};";
}

/**
 * Checks a message. Same limits as Blank (name 1–120, e-mail ≤ 200, phone ≤ 40, message 5–3000).
 *
 * @param array $input Raw fields.
 * @return array|WP_Error Clean fields.
 */
function blank_contact_validate( array $input ) {
	$name    = trim( sanitize_text_field( isset( $input['name'] ) ? (string) $input['name'] : '' ) );
	$email   = trim( sanitize_email( isset( $input['email'] ) ? (string) $input['email'] : '' ) );
	$phone   = trim( sanitize_text_field( isset( $input['phone'] ) ? (string) $input['phone'] : '' ) );
	$message = trim( sanitize_textarea_field( isset( $input['message'] ) ? (string) $input['message'] : '' ) );

	if ( '' === $name || mb_strlen( $name ) > 120 ) {
		return new WP_Error( 'blank_invalid', 'Indique ton nom.', array( 'status' => 400 ) );
	}
	if ( ! is_email( $email ) || mb_strlen( $email ) > 200 ) {
		return new WP_Error( 'blank_invalid', 'Adresse e-mail invalide.', array( 'status' => 400 ) );
	}
	if ( mb_strlen( $phone ) > 40 ) {
		return new WP_Error( 'blank_invalid', 'Numéro de téléphone trop long.', array( 'status' => 400 ) );
	}
	if ( mb_strlen( $message ) < 5 || mb_strlen( $message ) > 3000 ) {
		return new WP_Error( 'blank_invalid', 'Le message doit faire entre 5 et 3000 caractères.', array( 'status' => 400 ) );
	}
	return compact( 'name', 'email', 'phone', 'message' );
}

/**
 * Key of the visitor for the rate limit: hashed address, never stored in clear.
 *
 * @return string
 */
function blank_visitor_hash() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 32 );
}

/**
 * Counts one try; false when the visitor is over the limit.
 *
 * @param string $bucket Name of the limit.
 * @param int    $max    Tries per window.
 * @param int    $window Seconds.
 * @return bool
 */
function blank_rate_ok( $bucket, $max, $window ) {
	$key   = 'blank_rl_' . $bucket . '_' . blank_visitor_hash();
	$count = (int) get_transient( $key );
	if ( $count >= $max ) {
		return false;
	}
	set_transient( $key, $count + 1, $window );
	return true;
}

/**
 * Permission of the public contact route: valid nonce, empty honeypot, under the rate limit.
 *
 * @param WP_REST_Request $request Request.
 * @return true|WP_Error
 */
function blank_contact_permission( WP_REST_Request $request ) {
	$nonce = (string) $request->get_param( 'blank_nonce' );
	if ( ! wp_verify_nonce( $nonce, 'blank_contact' ) ) {
		return new WP_Error( 'blank_expired', 'La page a expiré, recharge-la puis réessaie.', array( 'status' => 403 ) );
	}
	if ( '' !== (string) $request->get_param( 'website' ) ) {
		return new WP_Error( 'blank_refused', 'Envoi impossible, réessaie plus tard.', array( 'status' => 400 ) );
	}
	if ( ! blank_rate_ok( 'contact', BLANK_CONTACT_PER_HOUR, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'blank_busy', 'Trop de messages envoyés. Réessaie dans une heure.', array( 'status' => 429 ) );
	}
	return true;
}

/**
 * Stores a message, warns the shop by e-mail and tells running plugins.
 *
 * @param array $fields Raw fields.
 * @return int|WP_Error Message id.
 */
function blank_contact_send( array $fields ) {
	global $wpdb;
	$clean = blank_contact_validate( $fields );
	if ( is_wp_error( $clean ) ) {
		return $clean;
	}
	$user_id = get_current_user_id();
	$ok      = $wpdb->insert(
		blank_contact_table(),
		array(
			'name'       => $clean['name'],
			'email'      => $clean['email'],
			'phone'      => $clean['phone'],
			'message'    => $clean['message'],
			'user_id'    => $user_id ? $user_id : null,
			'created_at' => current_time( 'mysql', true ),
		),
		array( '%s', '%s', '%s', '%s', '%d', '%s' )
	);
	if ( ! $ok ) {
		return new WP_Error( 'blank_failed', 'Envoi impossible, réessaie plus tard.', array( 'status' => 500 ) );
	}
	$id    = (int) $wpdb->insert_id;
	$shop  = blank_settings()['contact_email'];
	$shop  = $shop ? $shop : get_option( 'admin_email' );
	$lines = array(
		'Nom : ' . $clean['name'],
		'E-mail : ' . $clean['email'],
		'Téléphone : ' . ( $clean['phone'] ? $clean['phone'] : '—' ),
		'',
		$clean['message'],
	);
	blank_send_mail( $shop, 'Nouveau message de contact', $lines, array( 'reply_to' => $clean['email'] ) );
	do_action( 'blank_contact_message', $id, $clean, $user_id );
	return $id;
}

/**
 * REST routes of the contact messages.
 */
function blank_contact_routes() {
	register_rest_route(
		'blank/v1',
		'/contact',
		array(
			array(
				'methods'             => 'POST',
				'permission_callback' => 'blank_contact_permission',
				'callback'            => static function ( WP_REST_Request $request ) {
					$id = blank_contact_send( (array) $request->get_params() );
					return is_wp_error( $id ) ? $id : rest_ensure_response( array( 'ok' => true ) );
				},
			),
			array(
				'methods'             => 'GET',
				'permission_callback' => blank_rest_staff( 'messages' ),
				'callback'            => static function () {
					return rest_ensure_response( blank_contact_list( 100 ) );
				},
			),
		)
	);
	register_rest_route(
		'blank/v1',
		'/contact/(?P<id>\d+)',
		array(
			array(
				'methods'             => 'POST',
				'permission_callback' => blank_rest_staff( 'messages' ),
				'callback'            => static function ( WP_REST_Request $request ) {
					global $wpdb;
					$wpdb->update( blank_contact_table(), array( 'is_read' => 1 ), array( 'id' => (int) $request['id'] ), array( '%d' ), array( '%d' ) );
					return rest_ensure_response( array( 'ok' => true ) );
				},
			),
			array(
				'methods'             => 'DELETE',
				'permission_callback' => blank_rest_staff( 'messages' ),
				'callback'            => static function ( WP_REST_Request $request ) {
					global $wpdb;
					$wpdb->delete( blank_contact_table(), array( 'id' => (int) $request['id'] ), array( '%d' ) );
					return rest_ensure_response( array( 'ok' => true ) );
				},
			),
		)
	);
}

/**
 * Latest messages, for staff.
 *
 * @param int $limit Max rows.
 * @return array[]
 */
function blank_contact_list( $limit ) {
	global $wpdb;
	$table = blank_contact_table();
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is ours.
	return $wpdb->get_results( $wpdb->prepare( "SELECT id, name, email, phone, message, is_read, created_at FROM {$table} ORDER BY created_at DESC, id DESC LIMIT %d", (int) $limit ), ARRAY_A );
}

/**
 * Unread messages count.
 *
 * @return int
 */
function blank_contact_unread() {
	global $wpdb;
	$table = blank_contact_table();
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is ours.
	return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE is_read = 0" );
}

/**
 * [blank_contact] form.
 *
 * @return string
 */
function blank_contact_shortcode() {
	wp_enqueue_script( 'blank-contact', BLANK_CORE_URL . 'assets/contact.js', array(), BLANK_CORE_VERSION, true );
	wp_localize_script( 'blank-contact', 'blankContact', array( 'url' => esc_url_raw( rest_url( 'blank/v1/contact' ) ) ) );
	ob_start();
	?>
	<form class="blank-contact" novalidate>
		<input type="hidden" name="blank_nonce" value="<?php echo esc_attr( wp_create_nonce( 'blank_contact' ) ); ?>">
		<p class="blank-hp" aria-hidden="true" style="position:absolute;left:-9999px"><label>Site <input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
		<p><label>Nom *<br><input type="text" name="name" required maxlength="120"></label></p>
		<p><label>E-mail *<br><input type="email" name="email" required maxlength="200"></label></p>
		<p><label>Téléphone<br><input type="tel" name="phone" maxlength="40"></label></p>
		<p><label>Message *<br><textarea name="message" required minlength="5" maxlength="3000" rows="5"></textarea></label></p>
		<p><button type="submit">Envoyer</button></p>
		<p class="blank-contact-status" role="status"></p>
	</form>
	<?php
	return (string) ob_get_clean();
}
