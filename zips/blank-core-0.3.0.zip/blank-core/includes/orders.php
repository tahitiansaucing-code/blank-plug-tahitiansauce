<?php
/**
 * WooCommerce orders in the owner space. Reads and status changes go through WooCommerce's own API.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks of the orders menu.
 */
function blank_orders_init() {
	add_action( 'rest_api_init', 'blank_orders_routes' );
}

/**
 * Statuses an order may be set to, from WooCommerce.
 *
 * @return array<string,string> 'wc-processing' => 'En cours'
 */
function blank_order_statuses() {
	return function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
}

/**
 * Latest orders, as plain rows.
 *
 * @param int    $limit  Max rows.
 * @param string $status Optional status key without "wc-".
 * @return array[]
 */
function blank_orders_list( $limit = 50, $status = '' ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return array();
	}
	$args = array(
		'limit'   => (int) $limit,
		'orderby' => 'date',
		'order'   => 'DESC',
		'type'    => 'shop_order',
	);
	if ( '' !== $status ) {
		$args['status'] = array( sanitize_key( $status ) );
	}
	$rows = array();
	foreach ( wc_get_orders( $args ) as $order ) {
		$rows[] = array(
			'id'       => $order->get_id(),
			'number'   => $order->get_order_number(),
			'status'   => 'wc-' . $order->get_status(),
			'total'    => wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ),
			'customer' => trim( $order->get_formatted_billing_full_name() ),
			'email'    => $order->get_billing_email(),
			'date'     => $order->get_date_created() ? $order->get_date_created()->date_i18n( 'd/m/Y H:i' ) : '',
			'items'    => count( $order->get_items() ),
		);
	}
	return $rows;
}

/**
 * Changes an order status. Staff with access to "orders" only.
 *
 * @param int    $order_id Order.
 * @param string $status   Status key, with or without "wc-".
 * @return true|WP_Error
 */
function blank_order_set_status( $order_id, $status ) {
	if ( ! blank_staff_can( get_current_user_id(), 'orders' ) ) {
		return new WP_Error( 'blank_forbidden', 'Ton rôle n\'a pas accès aux commandes.', array( 'status' => 403 ) );
	}
	$status = 0 === strpos( (string) $status, 'wc-' ) ? (string) $status : 'wc-' . $status;
	if ( ! array_key_exists( $status, blank_order_statuses() ) ) {
		return new WP_Error( 'blank_invalid', 'Statut inconnu.', array( 'status' => 400 ) );
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( (int) $order_id ) : false;
	if ( ! $order || 'shop_order' !== $order->get_type() ) {
		return new WP_Error( 'blank_not_found', 'Commande introuvable.', array( 'status' => 404 ) );
	}
	$user = wp_get_current_user();
	$order->update_status( substr( $status, 3 ), sprintf( 'Statut changé depuis l\'espace propriétaire par %s.', $user->display_name ) );
	return true;
}

/**
 * REST routes of the orders menu.
 */
function blank_orders_routes() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	register_rest_route(
		'blank/v1',
		'/orders',
		array(
			'methods'             => 'GET',
			'permission_callback' => blank_rest_staff( 'orders' ),
			'callback'            => static function ( WP_REST_Request $request ) {
				return rest_ensure_response( blank_orders_list( 50, (string) $request->get_param( 'status' ) ) );
			},
		)
	);
	register_rest_route(
		'blank/v1',
		'/orders/(?P<id>\d+)/status',
		array(
			'methods'             => 'POST',
			'permission_callback' => blank_rest_staff( 'orders' ),
			'callback'            => static function ( WP_REST_Request $request ) {
				$done = blank_order_set_status( (int) $request['id'], (string) $request->get_param( 'status' ) );
				return is_wp_error( $done ) ? $done : rest_ensure_response( array( 'ok' => true ) );
			},
		)
	);
}
