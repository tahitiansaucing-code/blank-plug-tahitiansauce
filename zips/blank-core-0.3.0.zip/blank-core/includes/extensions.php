<?php
/**
 * Control center: catalog of Blank extensions, install, update, activate, deactivate, delete.
 *
 * The catalog and the zips come from one fixed public source (raw.githubusercontent.com),
 * never from an address typed by someone. Every zip is checked against the SHA-256 of the catalog.
 * Only the super-admin may act here: installing an extension runs code on the server.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The only host the catalog and the zips are read from. */
const BLANK_CATALOG_HOST = 'raw.githubusercontent.com';

/** Largest zip accepted, in bytes. */
const BLANK_ZIP_MAX = 20971520;

/**
 * Hooks of the control center.
 */
function blank_extensions_init() {
	add_action( 'rest_api_init', 'blank_extensions_routes' );
	add_action( 'admin_menu', 'blank_extensions_admin_menu' );
	add_action( 'admin_post_blank_extension', 'blank_extensions_admin_post' );
}

/**
 * Base address of the distribution repository. Can be changed in wp-config.php with
 * BLANK_CATALOG_BASE, but only to another path on the same fixed host.
 *
 * @return string Ends with a slash.
 */
function blank_catalog_base() {
	$base = defined( 'BLANK_CATALOG_BASE' ) ? (string) BLANK_CATALOG_BASE : 'https://raw.githubusercontent.com/tahitiansaucing-code/blank-plug-tahitiansauce/main/';
	$base = rtrim( $base, '/' ) . '/';
	$host = wp_parse_url( $base, PHP_URL_HOST );
	if ( 0 !== strpos( $base, 'https://' ) || BLANK_CATALOG_HOST !== $host ) {
		return 'https://raw.githubusercontent.com/tahitiansaucing-code/blank-plug-tahitiansauce/main/';
	}
	return $base;
}

/**
 * Checks one catalog entry. Unknown keys are dropped; a bad entry is skipped.
 *
 * @param mixed $item Raw entry.
 * @return array|null
 */
function blank_catalog_item( $item ) {
	if ( ! is_array( $item ) ) {
		return null;
	}
	$slug    = isset( $item['slug'] ) ? (string) $item['slug'] : '';
	$version = isset( $item['version'] ) ? (string) $item['version'] : '';
	$zip     = isset( $item['zip'] ) ? (string) $item['zip'] : '';
	$sha     = isset( $item['sha256'] ) ? strtolower( (string) $item['sha256'] ) : '';
	if ( ! preg_match( '/^blank-[a-z0-9-]{1,40}$/', $slug ) ) {
		return null;
	}
	if ( ! preg_match( '/^\d{1,3}\.\d{1,3}\.\d{1,3}$/', $version ) ) {
		return null;
	}
	if ( 'zips/' . $slug . '-' . $version . '.zip' !== $zip ) {
		return null;
	}
	if ( ! preg_match( '/^[a-f0-9]{64}$/', $sha ) ) {
		return null;
	}
	$requires = array();
	foreach ( isset( $item['requires'] ) && is_array( $item['requires'] ) ? $item['requires'] : array() as $req ) {
		$req = (string) $req;
		if ( 'woocommerce' === $req || preg_match( '/^blank-[a-z0-9-]{1,40}$/', $req ) ) {
			$requires[] = $req;
		}
	}
	return array(
		'slug'        => $slug,
		'name'        => mb_substr( sanitize_text_field( isset( $item['name'] ) ? (string) $item['name'] : $slug ), 0, 80 ),
		'description' => mb_substr( sanitize_text_field( isset( $item['description'] ) ? (string) $item['description'] : '' ), 0, 300 ),
		'version'     => $version,
		'requires'    => $requires,
		'zip'         => $zip,
		'sha256'      => $sha,
	);
}

/**
 * Checks a whole catalog document.
 *
 * @param mixed $doc Decoded JSON.
 * @return array<string,array> slug => entry
 */
function blank_parse_catalog( $doc ) {
	$items = is_array( $doc ) && isset( $doc['plugins'] ) && is_array( $doc['plugins'] ) ? $doc['plugins'] : array();
	$out   = array();
	foreach ( $items as $raw ) {
		$item = blank_catalog_item( $raw );
		if ( $item ) {
			$out[ $item['slug'] ] = $item;
		}
	}
	ksort( $out );
	return $out;
}

/**
 * Reads a file of the distribution repository. No redirect is followed.
 *
 * @param string $path    Path under the base (already checked).
 * @param array  $args    Extra request args.
 * @return array|WP_Error Response.
 */
function blank_catalog_get( $path, array $args = array() ) {
	$res = wp_safe_remote_get(
		blank_catalog_base() . $path,
		array_merge(
			array(
				'timeout'     => 20,
				'redirection' => 0,
				'user-agent'  => 'Blank-Core/' . BLANK_CORE_VERSION,
			),
			$args
		)
	);
	if ( is_wp_error( $res ) ) {
		return new WP_Error( 'blank_unreachable', 'Le catalogue est injoignable. Réessaie plus tard.', array( 'status' => 502 ) );
	}
	if ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return new WP_Error( 'blank_unreachable', 'Le catalogue est indisponible. Réessaie plus tard.', array( 'status' => 502 ) );
	}
	return $res;
}

/**
 * The catalog, cached for six hours.
 *
 * @param bool $fresh Skip the cache.
 * @return array|WP_Error
 */
function blank_catalog( $fresh = false ) {
	$cached = $fresh ? false : get_transient( 'blank_catalog' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$res = blank_catalog_get( 'catalog.json' );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$catalog = blank_parse_catalog( json_decode( wp_remote_retrieve_body( $res ), true ) );
	set_transient( 'blank_catalog', $catalog, 6 * HOUR_IN_SECONDS );
	return $catalog;
}

/**
 * Main file of an extension, relative to the plugins folder.
 *
 * @param string $slug Slug.
 * @return string
 */
function blank_extension_file( $slug ) {
	return $slug . '/' . $slug . '.php';
}

/**
 * Installed Blank extensions: slug => version.
 *
 * @return array<string,string>
 */
function blank_installed_extensions() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	wp_clean_plugins_cache( false );
	$out = array();
	foreach ( get_plugins() as $file => $data ) {
		$slug = dirname( $file );
		if ( preg_match( '/^blank-[a-z0-9-]+$/', $slug ) && blank_extension_file( $slug ) === $file ) {
			$out[ $slug ] = (string) $data['Version'];
		}
	}
	return $out;
}

/**
 * Is a requirement running? WooCommerce or a Blank extension.
 *
 * @param string $req Requirement.
 * @return bool
 */
function blank_requirement_running( $req ) {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	if ( 'woocommerce' === $req ) {
		return is_plugin_active( 'woocommerce/woocommerce.php' );
	}
	return is_plugin_active( blank_extension_file( $req ) );
}

/**
 * Rows shown in the control center: catalog merged with what is installed.
 *
 * @param array $catalog Catalog.
 * @return array[]
 */
function blank_extension_rows( array $catalog ) {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$installed = blank_installed_extensions();
	$rows      = array();
	foreach ( array_unique( array_merge( array_keys( $catalog ), array_keys( $installed ) ) ) as $slug ) {
		$item      = isset( $catalog[ $slug ] ) ? $catalog[ $slug ] : null;
		$version   = isset( $installed[ $slug ] ) ? $installed[ $slug ] : '';
		$available = $item ? $item['version'] : '';
		$missing   = array();
		foreach ( $item ? $item['requires'] : array() as $req ) {
			if ( ! blank_requirement_running( $req ) ) {
				$missing[] = $req;
			}
		}
		$rows[] = array(
			'slug'        => $slug,
			'name'        => $item ? $item['name'] : $slug,
			'description' => $item ? $item['description'] : '',
			'installed'   => $version,
			'available'   => $available,
			'update'      => '' !== $version && '' !== $available && version_compare( $available, $version, '>' ),
			'active'      => '' !== $version && is_plugin_active( blank_extension_file( $slug ) ),
			'requires'    => $item ? $item['requires'] : array(),
			'missing'     => $missing,
			'core'        => 'blank-core' === $slug,
		);
	}
	usort(
		$rows,
		static function ( $a, $b ) {
			return $a['core'] === $b['core'] ? strcmp( $a['name'], $b['name'] ) : ( $a['core'] ? -1 : 1 );
		}
	);
	return $rows;
}

/**
 * Checks a downloaded zip: size, hash, and a single top folder named after the slug.
 *
 * @param string $file   Local zip.
 * @param string $slug   Expected slug.
 * @param string $sha256 Expected hash.
 * @return true|WP_Error
 */
function blank_check_zip( $file, $slug, $sha256 ) {
	$size = @filesize( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	if ( ! $size || $size > BLANK_ZIP_MAX ) {
		return new WP_Error( 'blank_zip', 'Le fichier reçu est invalide.', array( 'status' => 502 ) );
	}
	if ( ! hash_equals( $sha256, hash_file( 'sha256', $file ) ) ) {
		return new WP_Error( 'blank_zip', 'Le fichier reçu ne correspond pas au catalogue. Installation annulée.', array( 'status' => 502 ) );
	}
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'blank_zip', 'Le serveur ne sait pas ouvrir les fichiers zip.', array( 'status' => 500 ) );
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $file ) ) {
		return new WP_Error( 'blank_zip', 'Le fichier reçu est invalide.', array( 'status' => 502 ) );
	}
	$ok   = $zip->numFiles > 0;
	$main = false;
	for ( $i = 0; $ok && $i < $zip->numFiles; $i++ ) {
		$name = (string) $zip->getNameIndex( $i );
		if ( 0 !== strpos( $name, $slug . '/' ) || false !== strpos( $name, '..' ) || false !== strpos( $name, '\\' ) ) {
			$ok = false;
		}
		if ( $slug . '/' . $slug . '.php' === $name ) {
			$main = true;
		}
	}
	$zip->close();
	if ( ! $ok || ! $main ) {
		return new WP_Error( 'blank_zip', 'Le contenu du fichier reçu est invalide.', array( 'status' => 502 ) );
	}
	return true;
}

/**
 * Downloads, checks and installs (or updates) one extension from the catalog.
 *
 * @param string $slug Slug.
 * @return true|WP_Error
 */
function blank_install_extension( $slug ) {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		return new WP_Error( 'blank_forbidden', 'Seul le super-admin installe des extensions.', array( 'status' => 403 ) );
	}
	$catalog = blank_catalog( true );
	if ( is_wp_error( $catalog ) ) {
		return $catalog;
	}
	if ( ! isset( $catalog[ $slug ] ) ) {
		return new WP_Error( 'blank_unknown', 'Extension absente du catalogue.', array( 'status' => 404 ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	$item      = $catalog[ $slug ];
	$installed = blank_installed_extensions();
	if ( isset( $installed[ $slug ] ) && version_compare( $item['version'], $installed[ $slug ], '<' ) ) {
		return new WP_Error( 'blank_older', 'La version installée est plus récente que celle du catalogue. Rien n\'a été changé.', array( 'status' => 409 ) );
	}
	$tmp  = wp_tempnam( $slug . '.zip' );
	$res  = blank_catalog_get(
		$item['zip'],
		array(
			'timeout'             => 60,
			'stream'              => true,
			'filename'            => $tmp,
			'limit_response_size' => BLANK_ZIP_MAX + 1,
		)
	);
	if ( is_wp_error( $res ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return $res;
	}
	$checked = blank_check_zip( $tmp, $slug, $item['sha256'] );
	if ( is_wp_error( $checked ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return $checked;
	}
	$done = blank_unpack_extension( $tmp );
	@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	if ( is_wp_error( $done ) ) {
		return $done;
	}
	wp_clean_plugins_cache( true );
	do_action( 'blank_extension_installed', $slug, $item['version'] );
	return true;
}

/**
 * Unpacks a checked zip into the plugins folder, replacing an older copy.
 *
 * @param string $file Local zip.
 * @return true|WP_Error
 */
function blank_unpack_extension( $file ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	if ( 'direct' !== get_filesystem_method( array(), WP_PLUGIN_DIR ) || ! WP_Filesystem() ) {
		return new WP_Error( 'blank_fs', 'Le serveur n\'autorise pas l\'écriture des extensions. Installe le zip depuis l\'hébergeur.', array( 'status' => 500 ) );
	}
	$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
	$result   = $upgrader->install( $file, array( 'overwrite_package' => true ) );
	if ( true !== $result ) {
		return new WP_Error( 'blank_install', 'L\'installation a échoué. Rien n\'a été activé.', array( 'status' => 500 ) );
	}
	return true;
}

/**
 * Activates an installed extension once its requirements run.
 *
 * @param string $slug Slug.
 * @return true|WP_Error
 */
function blank_activate_extension( $slug ) {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		return new WP_Error( 'blank_forbidden', 'Seul le super-admin active des extensions.', array( 'status' => 403 ) );
	}
	if ( ! isset( blank_installed_extensions()[ $slug ] ) ) {
		return new WP_Error( 'blank_unknown', 'Extension non installée.', array( 'status' => 404 ) );
	}
	$catalog  = blank_catalog();
	$requires = ! is_wp_error( $catalog ) && isset( $catalog[ $slug ] ) ? $catalog[ $slug ]['requires'] : array();
	$missing  = array_values(
		array_filter(
			$requires,
			static function ( $req ) {
				return ! blank_requirement_running( $req );
			}
		)
	);
	if ( $missing ) {
		return new WP_Error( 'blank_requires', 'Active d\'abord : ' . implode( ', ', $missing ) . '.', array( 'status' => 409 ) );
	}
	$result = activate_plugin( blank_extension_file( $slug ) );
	if ( is_wp_error( $result ) ) {
		return new WP_Error( 'blank_activate', 'L\'extension n\'a pas pu être activée.', array( 'status' => 500 ) );
	}
	return true;
}

/**
 * Active Blank extensions that need this one.
 *
 * @param string $slug Slug.
 * @return string[]
 */
function blank_extension_dependents( $slug ) {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$catalog = blank_catalog();
	if ( is_wp_error( $catalog ) ) {
		return array();
	}
	$out = array();
	foreach ( $catalog as $item ) {
		if ( in_array( $slug, $item['requires'], true ) && is_plugin_active( blank_extension_file( $item['slug'] ) ) ) {
			$out[] = $item['name'];
		}
	}
	return $out;
}

/**
 * Deactivates an extension. Blank Core is never turned off from here.
 *
 * @param string $slug Slug.
 * @return true|WP_Error
 */
function blank_deactivate_extension( $slug ) {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		return new WP_Error( 'blank_forbidden', 'Seul le super-admin désactive des extensions.', array( 'status' => 403 ) );
	}
	if ( 'blank-core' === $slug ) {
		return new WP_Error( 'blank_core', 'Blank Core se désactive depuis WordPress, pas d\'ici.', array( 'status' => 409 ) );
	}
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$dependents = blank_extension_dependents( $slug );
	if ( $dependents ) {
		return new WP_Error( 'blank_needed', 'Désactive d\'abord : ' . implode( ', ', $dependents ) . '.', array( 'status' => 409 ) );
	}
	deactivate_plugins( blank_extension_file( $slug ) );
	return true;
}

/**
 * Deletes an inactive extension; its uninstall.php removes its tables.
 *
 * @param string $slug Slug.
 * @return true|WP_Error
 */
function blank_delete_extension( $slug ) {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		return new WP_Error( 'blank_forbidden', 'Seul le super-admin supprime des extensions.', array( 'status' => 403 ) );
	}
	if ( 'blank-core' === $slug ) {
		return new WP_Error( 'blank_core', 'Blank Core se supprime depuis WordPress, pas d\'ici.', array( 'status' => 409 ) );
	}
	if ( ! isset( blank_installed_extensions()[ $slug ] ) ) {
		return new WP_Error( 'blank_unknown', 'Extension non installée.', array( 'status' => 404 ) );
	}
	if ( is_plugin_active( blank_extension_file( $slug ) ) ) {
		return new WP_Error( 'blank_active', 'Désactive l\'extension avant de la supprimer.', array( 'status' => 409 ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	if ( 'direct' !== get_filesystem_method( array(), WP_PLUGIN_DIR ) ) {
		return new WP_Error( 'blank_fs', 'Le serveur n\'autorise pas la suppression des extensions.', array( 'status' => 500 ) );
	}
	$result = delete_plugins( array( blank_extension_file( $slug ) ) );
	if ( true !== $result ) {
		return new WP_Error( 'blank_delete', 'La suppression a échoué.', array( 'status' => 500 ) );
	}
	return true;
}

/**
 * REST permission: the super-admin only.
 *
 * @return true|WP_Error
 */
function blank_rest_superadmin() {
	$user_id = get_current_user_id();
	if ( ! $user_id ) {
		return new WP_Error( 'blank_login', 'Connecte-toi pour continuer.', array( 'status' => 401 ) );
	}
	if ( ! blank_is_superadmin( $user_id ) ) {
		return new WP_Error( 'blank_forbidden', 'Réservé au super-admin.', array( 'status' => 403 ) );
	}
	return true;
}

/**
 * REST routes of the control center.
 */
function blank_extensions_routes() {
	register_rest_route(
		'blank/v1',
		'/extensions',
		array(
			'methods'             => 'GET',
			'permission_callback' => 'blank_rest_superadmin',
			'callback'            => static function ( WP_REST_Request $request ) {
				$catalog = blank_catalog( (bool) $request->get_param( 'fresh' ) );
				return rest_ensure_response( blank_extension_rows( is_wp_error( $catalog ) ? array() : $catalog ) );
			},
		)
	);
	foreach ( blank_extension_actions() as $action => $callback ) {
		register_rest_route(
			'blank/v1',
			'/extensions/(?P<slug>blank-[a-z0-9-]{1,40})/' . $action,
			array(
				'methods'             => 'POST',
				'permission_callback' => 'blank_rest_superadmin',
				'callback'            => static function ( WP_REST_Request $request ) use ( $callback ) {
					$done = call_user_func( $callback, (string) $request['slug'] );
					return is_wp_error( $done ) ? $done : rest_ensure_response( array( 'ok' => true ) );
				},
			)
		);
	}
}

/**
 * Public address of a published zip, for the "Télécharger" link.
 *
 * @param array $item Catalog entry.
 * @return string
 */
function blank_extension_zip_url( array $item ) {
	return blank_catalog_base() . $item['zip'];
}

/**
 * wp-admin page "Extensions Blank" (super-admin only): the list of the catalog,
 * with install, update, activate, deactivate, delete and download.
 *
 * @return string|false Page hook, false when the user is not the super-admin.
 */
function blank_extensions_admin_menu() {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		return false;
	}
	return add_plugins_page( 'Extensions Blank', 'Extensions Blank', 'activate_plugins', 'blank-extensions', 'blank_extensions_admin_page' );
}

/**
 * Actions the page can run.
 *
 * @return array<string,string>
 */
function blank_extension_actions() {
	return array(
		'install'    => 'blank_install_extension',
		'activate'   => 'blank_activate_extension',
		'deactivate' => 'blank_deactivate_extension',
		'delete'     => 'blank_delete_extension',
	);
}

/**
 * Handles a button of the page (admin-post.php?action=blank_extension).
 */
function blank_extensions_admin_post() {
	$do   = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
	$slug = isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
	check_admin_referer( 'blank_extension_' . $do . '_' . $slug );
	$back = admin_url( 'plugins.php?page=blank-extensions' );
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		wp_die( esc_html( 'Réservé au super-admin.' ), '', array( 'response' => 403 ) );
	}
	$actions = blank_extension_actions();
	if ( 'refresh' === $do ) {
		$result = blank_catalog( true );
		$result = is_wp_error( $result ) ? $result : true;
	} elseif ( isset( $actions[ $do ] ) && preg_match( '/^blank-[a-z0-9-]{1,40}$/', $slug ) ) {
		$result = call_user_func( $actions[ $do ], $slug );
	} else {
		$result = new WP_Error( 'blank_invalid', 'Action inconnue.' );
	}
	$messages = array(
		'install'    => 'Extension installée.',
		'activate'   => 'Extension activée.',
		'deactivate' => 'Extension désactivée.',
		'delete'     => 'Extension supprimée.',
		'refresh'    => 'Catalogue vérifié.',
	);
	set_transient(
		'blank_ext_notice_' . get_current_user_id(),
		is_wp_error( $result ) ? array( 'error', $result->get_error_message() ) : array( 'success', isset( $messages[ $do ] ) ? $messages[ $do ] : 'C\'est fait.' ),
		60
	);
	wp_safe_redirect( $back );
	exit;
}

/**
 * One button of the page, as a small form protected by a nonce.
 *
 * @param string $do      Action.
 * @param string $slug    Extension.
 * @param string $label   Text.
 * @param string $confirm Optional confirmation question.
 * @param string $class   Button class.
 * @return string
 */
function blank_extension_button( $do, $slug, $label, $confirm = '', $class = 'button' ) {
	return sprintf(
		'<form method="post" action="%1$s" style="display:inline-block;margin:0 4px 4px 0"%2$s><input type="hidden" name="action" value="blank_extension"><input type="hidden" name="do" value="%3$s"><input type="hidden" name="slug" value="%4$s">%5$s<button type="submit" class="%6$s">%7$s</button></form>',
		esc_url( admin_url( 'admin-post.php' ) ),
		$confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '',
		esc_attr( $do ),
		esc_attr( $slug ),
		wp_nonce_field( 'blank_extension_' . $do . '_' . $slug, '_wpnonce', true, false ),
		esc_attr( $class ),
		esc_html( $label )
	);
}

/**
 * Renders the page.
 */
function blank_extensions_admin_page() {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		wp_die( esc_html( 'Réservé au super-admin.' ), '', array( 'response' => 403 ) );
	}
	$catalog = blank_catalog();
	$error   = is_wp_error( $catalog ) ? $catalog->get_error_message() : '';
	$catalog = is_wp_error( $catalog ) ? array() : $catalog;
	$rows    = blank_extension_rows( $catalog );
	$notice  = get_transient( 'blank_ext_notice_' . get_current_user_id() );
	delete_transient( 'blank_ext_notice_' . get_current_user_id() );

	echo '<div class="wrap"><h1 class="wp-heading-inline">Extensions Blank</h1> ';
	echo blank_extension_button( 'refresh', '', 'Vérifier le catalogue', '', 'page-title-action' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	echo '<hr class="wp-header-end">';
	if ( is_array( $notice ) ) {
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $notice[0] ), esc_html( $notice[1] ) );
	}
	if ( $error ) {
		printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( $error ) );
	}
	printf(
		'<p>Catalogue : <code>%s</code>. Une nouvelle version peut mettre jusqu\'à 5 minutes à apparaître après sa publication.</p>',
		esc_html( blank_catalog_base() . 'catalog.json' )
	);
	echo '<table class="wp-list-table widefat striped"><thead><tr><th>Extension</th><th>Installée</th><th>Catalogue</th><th>État</th><th>Actions</th></tr></thead><tbody>';
	if ( ! $rows ) {
		echo '<tr><td colspan="5">Aucune extension dans le catalogue.</td></tr>';
	}
	foreach ( $rows as $row ) {
		$slug    = $row['slug'];
		$buttons = '';
		if ( '' === $row['installed'] && '' !== $row['available'] ) {
			$buttons .= blank_extension_button( 'install', $slug, 'Installer', '', 'button button-primary' );
		}
		if ( $row['update'] ) {
			$buttons .= blank_extension_button( 'install', $slug, 'Mettre à jour en ' . $row['available'], '', 'button button-primary' );
		}
		if ( '' !== $row['installed'] && ! $row['active'] ) {
			$buttons .= blank_extension_button( 'activate', $slug, 'Activer' );
			if ( ! $row['core'] ) {
				$buttons .= blank_extension_button( 'delete', $slug, 'Supprimer', 'Supprimer ' . $row['name'] . ' et toutes ses données ?', 'button button-link-delete' );
			}
		}
		if ( $row['active'] && ! $row['core'] ) {
			$buttons .= blank_extension_button( 'deactivate', $slug, 'Désactiver' );
		}
		if ( isset( $catalog[ $slug ] ) ) {
			$buttons .= sprintf( '<a class="button" href="%s">Télécharger le zip</a>', esc_url( blank_extension_zip_url( $catalog[ $slug ] ) ) );
		}
		$state = '' === $row['installed'] ? 'Non installée' : ( $row['active'] ? 'Active' : 'Inactive' );
		printf(
			'<tr><td><strong>%s</strong><br><small>%s</small>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
			esc_html( $row['name'] ),
			esc_html( $row['description'] ),
			$row['missing'] ? '<br><small style="color:#b32d2e">' . esc_html( 'Nécessite : ' . implode( ', ', $row['missing'] ) ) . '</small>' : '',
			esc_html( $row['installed'] ? $row['installed'] : '—' ),
			esc_html( $row['available'] ? $row['available'] : 'Hors catalogue' ),
			esc_html( $state ),
			$buttons // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts.
		);
	}
	echo '</tbody></table></div>';
}
