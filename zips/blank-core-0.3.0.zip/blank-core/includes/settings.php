<?php
/**
 * Site settings (option blank_settings) and theme (option blank_theme).
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const BLANK_DEFAULT_THEME = 'tropical-beam';

/**
 * Hooks of the settings.
 */
function blank_settings_init() {
	add_action( 'rest_api_init', 'blank_settings_routes' );
}

/**
 * Theme ids, from Blank's src/lib/themes.ts.
 *
 * @return array<string,string>
 */
function blank_themes() {
	return array(
		'tropical-beam' => 'Tropical Beam',
		'quiet-luxury'  => 'Quiet Luxury',
		'dynamic-bomb'  => 'Dynamic Bomb',
		'pop-colors'    => 'Pop Colors',
		'kawaii'        => 'Kawaii',
		'secret-sunset' => 'Secret Sunset',
	);
}

/**
 * Settings and their defaults. Fields listed in blank_private_setting_keys() never leave the server.
 *
 * @return array<string,mixed>
 */
function blank_setting_defaults() {
	return array(
		'site_name'        => 'Blank Light',
		'logo_url'         => '',
		'hero_subtitle'    => '',
		'contact_email'    => '',
		'public_phone'     => '',
		'footer_copyright' => '',
		'timezone'         => 'Pacific/Tahiti',
		'email_templates'  => array(),
	);
}

/**
 * Fields kept out of anything a visitor can read.
 *
 * @return string[]
 */
function blank_private_setting_keys() {
	return array( 'contact_email', 'email_templates' );
}

/**
 * Every setting, with defaults filled in. Server only.
 *
 * @return array<string,mixed>
 */
function blank_settings() {
	$saved = get_option( 'blank_settings', array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	return array_merge( blank_setting_defaults(), array_intersect_key( $saved, blank_setting_defaults() ) );
}

/**
 * Settings a visitor may read: no contact email, no e-mail templates.
 *
 * @return array<string,mixed>
 */
function blank_public_settings() {
	$public          = array_diff_key( blank_settings(), array_flip( blank_private_setting_keys() ) );
	$public['theme'] = blank_theme();
	return $public;
}

/**
 * Cleans settings sent by the owner space. Unknown keys are dropped.
 *
 * @param array $input Raw values.
 * @return array<string,mixed>
 */
function blank_sanitize_settings( array $input ) {
	$clean = array();
	foreach ( $input as $key => $value ) {
		switch ( $key ) {
			case 'site_name':
			case 'hero_subtitle':
			case 'public_phone':
				$clean[ $key ] = mb_substr( sanitize_text_field( (string) $value ), 0, 200 );
				break;
			case 'footer_copyright':
				$clean[ $key ] = mb_substr( wp_kses_post( (string) $value ), 0, 500 );
				break;
			case 'logo_url':
				$clean[ $key ] = esc_url_raw( (string) $value, array( 'https', 'http' ) );
				break;
			case 'contact_email':
				$email         = sanitize_email( (string) $value );
				$clean[ $key ] = is_email( $email ) ? $email : '';
				break;
			case 'timezone':
				$clean[ $key ] = in_array( $value, timezone_identifiers_list(), true ) ? $value : 'Pacific/Tahiti';
				break;
		}
	}
	return $clean;
}

/**
 * Saves part of the settings.
 *
 * @param array $input Raw values.
 * @return array<string,mixed> Settings after save.
 */
function blank_update_settings( array $input ) {
	$next = array_merge( blank_settings(), blank_sanitize_settings( $input ) );
	update_option( 'blank_settings', $next, false );
	return $next;
}

/**
 * Active theme id.
 *
 * @return string
 */
function blank_theme() {
	$theme = get_option( 'blank_theme', BLANK_DEFAULT_THEME );
	return array_key_exists( $theme, blank_themes() ) ? $theme : BLANK_DEFAULT_THEME;
}

/**
 * Changes the theme. Super-admin only.
 *
 * @param string $theme Theme id.
 * @return true|WP_Error
 */
function blank_set_theme( $theme ) {
	if ( ! blank_is_superadmin( get_current_user_id() ) ) {
		return new WP_Error( 'blank_forbidden', 'Seul le super-admin change le thème.', array( 'status' => 403 ) );
	}
	if ( ! array_key_exists( $theme, blank_themes() ) ) {
		return new WP_Error( 'blank_invalid', 'Thème inconnu.', array( 'status' => 400 ) );
	}
	update_option( 'blank_theme', $theme );
	return true;
}

/**
 * REST routes of the settings.
 */
function blank_settings_routes() {
	register_rest_route(
		'blank/v1',
		'/settings',
		array(
			array(
				'methods'             => 'GET',
				'permission_callback' => blank_rest_staff( 'settings' ),
				'callback'            => static function () {
					return rest_ensure_response( blank_settings() + array( 'theme' => blank_theme() ) );
				},
			),
			array(
				'methods'             => 'POST',
				'permission_callback' => blank_rest_staff( 'settings' ),
				'callback'            => static function ( WP_REST_Request $request ) {
					$body = $request->get_json_params();
					if ( ! is_array( $body ) ) {
						return new WP_Error( 'blank_invalid', 'Réglages illisibles.', array( 'status' => 400 ) );
					}
					if ( isset( $body['theme'] ) && $body['theme'] !== blank_theme() ) {
						$done = blank_set_theme( (string) $body['theme'] );
						if ( is_wp_error( $done ) ) {
							return $done;
						}
					}
					unset( $body['theme'] );
					return rest_ensure_response( blank_update_settings( $body ) + array( 'theme' => blank_theme() ) );
				},
			),
		)
	);
	register_rest_route(
		'blank/v1',
		'/settings/public',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => static function () {
				return rest_ensure_response( blank_public_settings() );
			},
		)
	);
}
