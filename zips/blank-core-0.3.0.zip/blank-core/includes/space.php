<?php
/**
 * Owner space at /tsuki: a front page for owners and team members, menus filtered by role.
 *
 * Plugins add menus through `blank_staff_menus`:
 * [ 'key' => 'devis', 'label' => 'Devis', 'render' => callable( int $user_id ), 'order' => 40, 'super' => false ].
 * A menu only shows to staff allowed in its area (its key) by blank_staff_can(); 'super' => true keeps it for the super-admin.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const BLANK_SPACE_SLUG = 'tsuki';

/**
 * Hooks of the owner space.
 */
function blank_space_init() {
	add_action( 'init', 'blank_space_rewrite' );
	add_filter( 'query_vars', 'blank_space_query_vars' );
	add_action( 'template_redirect', 'blank_space_render' );
	add_filter( 'login_redirect', 'blank_space_login_redirect', 10, 3 );
}

/**
 * URL of the owner space, optionally on one menu.
 *
 * @param string $tab Menu key.
 * @return string
 */
function blank_space_url( $tab = '' ) {
	$url = home_url( '/' . BLANK_SPACE_SLUG . '/' );
	return '' === $tab ? $url : add_query_arg( 'tab', rawurlencode( $tab ), $url );
}

/**
 * Rewrite rule of /tsuki.
 */
function blank_space_rewrite() {
	add_rewrite_rule( '^' . BLANK_SPACE_SLUG . '/?$', 'index.php?blank_space=1', 'top' );
}

/**
 * Query var of the owner space.
 *
 * @param string[] $vars Vars.
 * @return string[]
 */
function blank_space_query_vars( $vars ) {
	$vars[] = 'blank_space';
	return $vars;
}

/**
 * Owners and team members land in the owner space after login.
 *
 * @param string           $redirect  Requested URL.
 * @param string           $requested Raw request.
 * @param WP_User|WP_Error $user      User.
 * @return string
 */
function blank_space_login_redirect( $redirect, $requested, $user ) {
	if ( $user instanceof WP_User && blank_should_leave_admin( $user->ID, false ) && false !== strpos( (string) $redirect, '/wp-admin' ) ) {
		return blank_space_url();
	}
	return $redirect;
}

/**
 * Menus of the socle, then those of running plugins.
 *
 * @return array<string,array{key:string,label:string,render:callable,order:int}>
 */
function blank_staff_menus() {
	$menus = array(
		array(
			'key'    => 'home',
			'label'  => 'Accueil',
			'render' => 'blank_space_home',
			'order'  => 0,
		),
		array(
			'key'    => 'messages',
			'label'  => 'Messages',
			'render' => 'blank_space_messages',
			'order'  => 30,
		),
		array(
			'key'    => 'settings',
			'label'  => 'Réglages',
			'render' => 'blank_space_settings',
			'order'  => 90,
		),
	);
	if ( class_exists( 'WooCommerce' ) ) {
		$menus[] = array(
			'key'    => 'orders',
			'label'  => 'Commandes',
			'render' => 'blank_space_orders',
			'order'  => 10,
		);
	}
	$menus = apply_filters( 'blank_staff_menus', $menus );
	$valid = array();
	foreach ( is_array( $menus ) ? $menus : array() as $menu ) {
		if ( ! is_array( $menu ) || empty( $menu['key'] ) || empty( $menu['label'] ) || empty( $menu['render'] ) || ! is_callable( $menu['render'] ) ) {
			continue;
		}
		$key           = sanitize_key( $menu['key'] );
		$valid[ $key ] = array(
			'key'    => $key,
			'label'  => (string) $menu['label'],
			'render' => $menu['render'],
			'order'  => isset( $menu['order'] ) ? (int) $menu['order'] : 50,
			'super'  => ! empty( $menu['super'] ),
		);
	}
	uasort(
		$valid,
		static function ( $a, $b ) {
			return $a['order'] - $b['order'];
		}
	);
	return $valid;
}

/**
 * Menus this user may open.
 *
 * @param int $user_id User.
 * @return array
 */
function blank_menus_for( $user_id ) {
	return array_filter(
		blank_staff_menus(),
		static function ( $menu ) use ( $user_id ) {
			if ( $menu['super'] ) {
				return blank_is_superadmin( $user_id );
			}
			return blank_staff_can( $user_id, $menu['key'] );
		}
	);
}

/**
 * Serves /tsuki.
 */
function blank_space_render() {
	if ( ! get_query_var( 'blank_space' ) ) {
		return;
	}
	nocache_headers();
	$user_id = get_current_user_id();
	if ( ! $user_id ) {
		wp_safe_redirect( wp_login_url( blank_space_url() ) );
		exit;
	}
	if ( ! blank_is_staff( $user_id ) ) {
		status_header( 403 );
		blank_space_page( 'Accès réservé', '<p class="blank-empty">Cet espace est réservé à l\'équipe du site.</p>', array(), '' );
		exit;
	}
	$menus  = blank_menus_for( $user_id );
	$tab    = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'home'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- navigation only.
	$active = isset( $menus[ $tab ] ) ? $menus[ $tab ] : reset( $menus );
	ob_start();
	if ( $active ) {
		call_user_func( $active['render'], $user_id );
	} else {
		echo '<p class="blank-empty">Aucun menu n\'est ouvert pour ton rôle.</p>';
	}
	blank_space_page( $active ? $active['label'] : 'Espace', (string) ob_get_clean(), $menus, $active ? $active['key'] : '' );
	exit;
}

/**
 * Prints the whole page. $content is already escaped by the menu that built it.
 *
 * @param string $title   Title.
 * @param string $content HTML.
 * @param array  $menus   Menus.
 * @param string $active  Active key.
 */
function blank_space_page( $title, $content, array $menus, $active ) {
	$site = blank_settings()['site_name'];
	?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html( $title . ' · ' . $site ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( BLANK_CORE_URL . 'assets/space.css?ver=' . BLANK_CORE_VERSION ); ?>">
</head>
<body class="blank-space" data-theme="<?php echo esc_attr( blank_theme() ); ?>">
<header class="blank-top">
	<a class="blank-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( $site ); ?></a>
	<a class="blank-out" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">Déconnexion</a>
</header>
<div class="blank-wrap">
	<?php if ( $menus ) : ?>
	<nav class="blank-nav" aria-label="Menus">
		<?php foreach ( $menus as $menu ) : ?>
			<a href="<?php echo esc_url( blank_space_url( $menu['key'] ) ); ?>"<?php echo $menu['key'] === $active ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $menu['label'] ); ?></a>
		<?php endforeach; ?>
	</nav>
	<?php endif; ?>
	<main class="blank-main">
		<h1><?php echo esc_html( $title ); ?></h1>
		<p class="blank-status" role="status" hidden></p>
		<?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts. ?>
	</main>
</div>
<script>window.blankSpace = <?php echo wp_json_encode( array( 'root' => esc_url_raw( rest_url( 'blank/v1/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) ); ?>;</script>
<script src="<?php echo esc_url( BLANK_CORE_URL . 'assets/space.js?ver=' . BLANK_CORE_VERSION ); ?>"></script>
</body>
</html>
	<?php
}

/**
 * Accueil: a few counters.
 *
 * @param int $user_id User.
 */
function blank_space_home( $user_id ) {
	$cards = array();
	if ( blank_staff_can( $user_id, 'messages' ) ) {
		$cards[] = array( 'Messages non lus', blank_contact_unread(), blank_space_url( 'messages' ) );
	}
	if ( class_exists( 'WooCommerce' ) && blank_staff_can( $user_id, 'orders' ) ) {
		$cards[] = array( 'Commandes à traiter', count( wc_get_orders( array( 'status' => array( 'processing', 'on-hold' ), 'limit' => 100, 'return' => 'ids', 'type' => 'shop_order' ) ) ), blank_space_url( 'orders' ) );
	}
	$cards = apply_filters( 'blank_space_home_cards', $cards, $user_id );
	echo '<div class="blank-cards">';
	foreach ( $cards as $card ) {
		printf( '<a class="blank-card" href="%s"><span>%s</span><strong>%s</strong></a>', esc_url( $card[2] ), esc_html( $card[0] ), esc_html( (string) $card[1] ) );
	}
	echo '</div>';
	do_action( 'blank_slot_space_home', $user_id );
}

/**
 * Messages de contact.
 */
function blank_space_messages() {
	$rows = blank_contact_list( 100 );
	if ( ! $rows ) {
		echo '<p class="blank-empty">Aucun message pour l\'instant.</p>';
		return;
	}
	echo '<ul class="blank-list">';
	foreach ( $rows as $row ) {
		$id = (int) $row['id'];
		printf(
			'<li class="blank-item%1$s" id="msg-%2$d"><div class="blank-item-head"><strong>%3$s</strong> <a href="mailto:%4$s">%5$s</a> %6$s <time>%7$s</time></div><p>%8$s</p><div class="blank-actions">%9$s<button type="button" data-blank-action="contact/%2$d" data-method="DELETE" data-confirm="Supprimer ce message ?" data-remove="#msg-%2$d">Supprimer</button></div></li>',
			$row['is_read'] ? '' : ' is-new',
			$id,
			esc_html( $row['name'] ),
			esc_attr( $row['email'] ),
			esc_html( $row['email'] ),
			$row['phone'] ? esc_html( '· ' . $row['phone'] ) : '',
			esc_html( get_date_from_gmt( $row['created_at'], 'd/m/Y H:i' ) ),
			nl2br( esc_html( $row['message'] ) ),
			$row['is_read'] ? '' : sprintf( '<button type="button" data-blank-action="contact/%d" data-method="POST" data-done="Marqué comme lu.">Marquer comme lu</button>', $id )
		);
	}
	echo '</ul>';
}

/**
 * Commandes WooCommerce.
 */
function blank_space_orders() {
	$rows     = blank_orders_list( 50 );
	$statuses = blank_order_statuses();
	if ( ! $rows ) {
		echo '<p class="blank-empty">Aucune commande pour l\'instant.</p>';
		return;
	}
	echo '<div class="blank-table"><table><thead><tr><th>N°</th><th>Date</th><th>Client</th><th>Total</th><th>Statut</th></tr></thead><tbody>';
	foreach ( $rows as $row ) {
		$options = '';
		foreach ( $statuses as $key => $label ) {
			$options .= sprintf( '<option value="%s"%s>%s</option>', esc_attr( $key ), selected( $key, $row['status'], false ), esc_html( $label ) );
		}
		printf(
			'<tr><td>%s</td><td>%s</td><td>%s<br><small>%s</small></td><td>%s</td><td><select data-blank-select="orders/%d/status" data-field="status" aria-label="Statut">%s</select></td></tr>',
			esc_html( '#' . $row['number'] ),
			esc_html( $row['date'] ),
			esc_html( $row['customer'] ? $row['customer'] : '—' ),
			esc_html( $row['email'] ),
			esc_html( $row['total'] ),
			(int) $row['id'],
			$options // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		);
	}
	echo '</tbody></table></div>';
}

/**
 * Réglages du site; le thème n'est modifiable que par le super-admin.
 *
 * @param int $user_id User.
 */
function blank_space_settings( $user_id ) {
	$s     = blank_settings();
	$super = blank_is_superadmin( $user_id );
	$text  = array(
		'site_name'     => 'Nom du site',
		'hero_subtitle' => 'Sous-titre de l\'accueil',
		'contact_email' => 'E-mail qui reçoit les messages (jamais affiché)',
		'public_phone'  => 'Téléphone public',
		'logo_url'      => 'Adresse du logo',
	);
	echo '<form class="blank-form" data-blank-form="settings">';
	foreach ( $text as $key => $label ) {
		$type = 'contact_email' === $key ? 'email' : ( 'logo_url' === $key ? 'url' : 'text' );
		printf( '<label>%s<input type="%s" name="%s" value="%s"></label>', esc_html( $label ), esc_attr( $type ), esc_attr( $key ), esc_attr( (string) $s[ $key ] ) );
	}
	printf( '<label>Copyright du pied de page<textarea name="footer_copyright" rows="2">%s</textarea></label>', esc_textarea( (string) $s['footer_copyright'] ) );
	if ( $super ) {
		echo '<label>Thème<select name="theme">';
		foreach ( blank_themes() as $id => $label ) {
			printf( '<option value="%s"%s>%s</option>', esc_attr( $id ), selected( $id, blank_theme(), false ), esc_html( $label ) );
		}
		echo '</select></label>';
	}
	echo '<button type="submit">Enregistrer</button></form>';
	do_action( 'blank_slot_space_settings', $user_id );
}
