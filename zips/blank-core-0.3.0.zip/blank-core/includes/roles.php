<?php
/**
 * Team roles. The site's super-admin is the WordPress administrator.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Capability that opens the owner space. */
const BLANK_CAP_SPACE = 'blank_space';

/**
 * Team roles created by the socle, with their label.
 *
 * @return array<string,string>
 */
function blank_team_roles() {
	return array(
		'blank_owner' => 'Propriétaire',
		'blank_staff' => 'Équipe',
	);
}

/**
 * Creates the roles. Safe to run again.
 */
function blank_install_roles() {
	foreach ( blank_team_roles() as $role => $label ) {
		if ( ! get_role( $role ) ) {
			add_role( $role, $label, array( 'read' => true ) );
		}
		$object = get_role( $role );
		$object->add_cap( 'read' );
		$object->add_cap( BLANK_CAP_SPACE );
	}
	if ( ! get_role( 'customer' ) ) {
		add_role( 'customer', 'Client', array( 'read' => true ) );
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		$admin->add_cap( BLANK_CAP_SPACE );
	}
}

/**
 * Removes the team roles; their members become customers.
 */
function blank_remove_roles() {
	foreach ( array_keys( blank_team_roles() ) as $role ) {
		$users = get_users(
			array(
				'role'   => $role,
				'fields' => 'ID',
			)
		);
		foreach ( $users as $user_id ) {
			$user = new WP_User( (int) $user_id );
			$user->remove_role( $role );
			if ( empty( $user->roles ) ) {
				$user->add_role( 'customer' );
			}
		}
		remove_role( $role );
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		$admin->remove_cap( BLANK_CAP_SPACE );
	}
}

/**
 * Gives or takes a team role. Only the super-admin may, and never on their own account.
 *
 * @param int    $target_id User whose role changes.
 * @param string $role      Team role, or '' to take every team role away.
 * @return true|WP_Error
 */
function blank_assign_team_role( $target_id, $role ) {
	$actor_id  = get_current_user_id();
	$target_id = (int) $target_id;
	if ( ! blank_is_superadmin( $actor_id ) ) {
		return new WP_Error( 'blank_forbidden', 'Seul le super-admin attribue un rôle d\'équipe.', array( 'status' => 403 ) );
	}
	if ( $actor_id === $target_id ) {
		return new WP_Error( 'blank_forbidden', 'Un compte ne change pas son propre rôle.', array( 'status' => 403 ) );
	}
	if ( '' !== $role && ! array_key_exists( $role, blank_team_roles() ) ) {
		return new WP_Error( 'blank_invalid', 'Rôle inconnu.', array( 'status' => 400 ) );
	}
	$user = get_userdata( $target_id );
	if ( ! $user ) {
		return new WP_Error( 'blank_not_found', 'Compte introuvable.', array( 'status' => 404 ) );
	}
	if ( in_array( 'administrator', (array) $user->roles, true ) ) {
		return new WP_Error( 'blank_forbidden', 'Le rôle d\'un administrateur ne se change pas ici.', array( 'status' => 403 ) );
	}
	foreach ( array_keys( blank_team_roles() ) as $team_role ) {
		$user->remove_role( $team_role );
	}
	if ( '' !== $role ) {
		$user->add_role( $role );
	} elseif ( empty( $user->roles ) ) {
		$user->add_role( 'customer' );
	}
	return true;
}

/**
 * Nobody but the super-admin may promote someone, and nobody may promote themselves.
 *
 * @param string[] $caps    Primitive caps.
 * @param string   $cap     Meta cap.
 * @param int      $user_id Acting user.
 * @param array    $args    Extra args (target user id first).
 * @return string[]
 */
function blank_guard_promote( $caps, $cap, $user_id, $args ) {
	if ( 'promote_user' !== $cap ) {
		return $caps;
	}
	$target = isset( $args[0] ) ? (int) $args[0] : 0;
	if ( $target === (int) $user_id || ! blank_is_superadmin( $user_id ) ) {
		$caps[] = 'do_not_allow';
	}
	return $caps;
}
