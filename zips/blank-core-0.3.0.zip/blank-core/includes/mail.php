<?php
/**
 * Shared e-mail shell. Plugins declare their e-mails through the `blank_mails` filter.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Colors of the active theme used in e-mails (from Blank's src/index.css).
 *
 * @return array{bg:string,card:string,text:string,primary:string,border:string}
 */
function blank_mail_colors() {
	$palettes = array(
		'tropical-beam' => array(
			'bg'      => 'hsl(40,48%,96%)',
			'card'    => 'hsl(40,50%,98%)',
			'text'    => 'hsl(174,35%,14%)',
			'primary' => 'hsl(174,52%,28%)',
			'border'  => 'hsl(40,22%,84%)',
		),
	);
	$theme = blank_theme();
	$base  = $palettes['tropical-beam'];
	return isset( $palettes[ $theme ] ) ? $palettes[ $theme ] : apply_filters( 'blank_mail_colors', $base, $theme );
}

/**
 * Wraps lines of text in the common HTML shell. Every line is escaped.
 *
 * @param string   $title  Heading.
 * @param string[] $lines  Body lines; '' makes a gap.
 * @param array    $button Optional ['label' => ..., 'url' => ...].
 * @return string
 */
function blank_mail_html( $title, array $lines, array $button = array() ) {
	$c    = blank_mail_colors();
	$site = blank_settings()['site_name'];
	$body = '';
	foreach ( $lines as $line ) {
		$body .= '' === $line ? '<br>' : '<p style="margin:0 0 8px">' . nl2br( esc_html( $line ) ) . '</p>';
	}
	if ( ! empty( $button['label'] ) && ! empty( $button['url'] ) ) {
		$body .= '<p style="margin:20px 0 0"><a href="' . esc_url( $button['url'] ) . '" style="display:inline-block;padding:10px 18px;border-radius:12px;background:' . esc_attr( $c['primary'] ) . ';color:#fff;text-decoration:none">' . esc_html( $button['label'] ) . '</a></p>';
	}
	return '<div style="background:' . esc_attr( $c['bg'] ) . ';padding:24px;font-family:Arial,sans-serif;color:' . esc_attr( $c['text'] ) . '">'
		. '<div style="max-width:560px;margin:0 auto;background:' . esc_attr( $c['card'] ) . ';border:1px solid ' . esc_attr( $c['border'] ) . ';border-radius:12px;padding:24px">'
		. '<p style="margin:0 0 4px;font-size:13px;opacity:.7">' . esc_html( $site ) . '</p>'
		. '<h1 style="margin:0 0 16px;font-size:20px">' . esc_html( $title ) . '</h1>'
		. $body . '</div></div>';
}

/**
 * Sends an e-mail in the common shell.
 *
 * @param string   $to      Recipient.
 * @param string   $subject Subject and heading.
 * @param string[] $lines   Body lines.
 * @param array    $opts    reply_to, button.
 * @return bool
 */
function blank_send_mail( $to, $subject, array $lines, array $opts = array() ) {
	if ( ! is_email( $to ) ) {
		return false;
	}
	$headers = array( 'Content-Type: text/html; charset=UTF-8' );
	if ( ! empty( $opts['reply_to'] ) && is_email( $opts['reply_to'] ) ) {
		$headers[] = 'Reply-To: ' . sanitize_email( $opts['reply_to'] );
	}
	$button = isset( $opts['button'] ) && is_array( $opts['button'] ) ? $opts['button'] : array();
	return wp_mail( $to, $subject, blank_mail_html( $subject, $lines, $button ), $headers );
}

/**
 * E-mails declared by running plugins: key => ['label' => ..., 'module' => ...].
 *
 * @return array<string,array>
 */
function blank_mails() {
	$mails = apply_filters( 'blank_mails', array() );
	return is_array( $mails ) ? $mails : array();
}
