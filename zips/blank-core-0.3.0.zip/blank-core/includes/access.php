<?php
/**
 * Who may do what. Every check runs on the server.
 *
 * @package blank-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hooks of the access layer.
 */
function blank_access_init() {
	add_filter( 'map_meta_cap', 'blank_guard_promote', 10, 4 );
	add_action( 'admin_init', 'blank_leave_admin', 1 );
	add_filter( 'show_admin_bar', 'blank_admin_bar' );
}

/**
 * The super-admin is a WordPress administrator (a network super admin on multisite).
 *
 * @param int $user_id User.
 * @return bool
 */
function blank_is_superadmin( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return false;
	}
	if ( is_multisite() && is_super_admin( $user_id ) ) {
		return true;
	}
	$user = get_userdata( $user_id );
	return $user && in_array( 'administrator', (array) $user->roles, true );
}

/**
 * Staff: super-admin, owner or team member.
 *
 * @param int $user_id User.
 * @return bool
 */
function blank_is_staff( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return false;
	}
	return blank_is_superadmin( $user_id ) || user_can( $user_id, BLANK_CAP_SPACE );
}

/**
 * Any refusal wins, silence lets through.
 *
 * @param array $answers true, false or null from each plugin.
 * @return bool
 */
function blank_staff_verdict( array $answers ) {
	return ! in_array( false, $answers, true );
}

/**
 * May this user act in this area of the owner space (menu key)?
 * The super-admin is never asked; other staff pass unless a plugin refuses.
 *
 * @param int    $user_id User.
 * @param string $area    Menu key.
 * @return bool
 */
function blank_staff_can( $user_id, $area ) {
	$user_id = (int) $user_id;
	if ( blank_is_superadmin( $user_id ) ) {
		return true;
	}
	if ( ! blank_is_staff( $user_id ) ) {
		return false;
	}
	/**
	 * Answers of plugins about one staff member and one area.
	 * Each listener appends true, false or null to the array.
	 */
	$answers = apply_filters( 'blank_staff_allowed', array(), $user_id, (string) $area );
	if ( ! is_array( $answers ) ) {
		return false;
	}
	foreach ( $answers as $answer ) {
		if ( true !== $answer && false !== $answer && null !== $answer ) {
			return false;
		}
	}
	return blank_staff_verdict( $answers );
}

/**
 * REST permission helper: logged-in staff allowed in the area.
 *
 * @param string $area Menu key.
 * @return callable
 */
function blank_rest_staff( $area ) {
	return static function () use ( $area ) {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new WP_Error( 'blank_login', 'Connecte-toi pour continuer.', array( 'status' => 401 ) );
		}
		if ( ! blank_staff_can( $user_id, $area ) ) {
			return new WP_Error( 'blank_forbidden', 'Ton rôle n\'a pas accès à cette partie de l\'administration.', array( 'status' => 403 ) );
		}
		return true;
	};
}

/**
 * Owners and team members use /tsuki, never /wp-admin.
 *
 * @param int  $user_id  User.
 * @param bool $is_ajax  admin-ajax.php request.
 * @param bool $is_post  admin-post.php request.
 * @return bool
 */
function blank_should_leave_admin( $user_id, $is_ajax, $is_post = false ) {
	if ( $is_ajax || $is_post ) {
		return false;
	}
	return blank_is_staff( $user_id ) && ! blank_is_superadmin( $user_id );
}

/**
 * Sends owners and team members from /wp-admin to the owner space.
 */
function blank_leave_admin() {
	$is_post = isset( $GLOBALS['pagenow'] ) && 'admin-post.php' === $GLOBALS['pagenow'];
	if ( blank_should_leave_admin( get_current_user_id(), wp_doing_ajax(), $is_post ) ) {
		wp_safe_redirect( blank_space_url() );
		exit;
	}
}

/**
 * Hides the admin bar for owners and team members.
 *
 * @param bool $show Current value.
 * @return bool
 */
function blank_admin_bar( $show ) {
	$user_id = get_current_user_id();
	if ( blank_is_staff( $user_id ) && ! blank_is_superadmin( $user_id ) ) {
		return false;
	}
	return $show;
}

/**
 * Checks, when a Blank plugin is activated, that the plugins it needs are active.
 * Deactivates it and stops with a French message otherwise.
 *
 * @param string   $plugin_file Main file of the plugin being activated.
 * @param string[] $requires    Required plugins: 'blank-core', 'woocommerce' or another Blank slug.
 */
function blank_require_or_die( $plugin_file, array $requires ) {
	$missing = blank_missing_requirements( $requires );
	if ( $missing ) {
		deactivate_plugins( plugin_basename( $plugin_file ) );
		wp_die(
			esc_html( 'Cette extension a besoin de : ' . implode( ', ', $missing ) . '. Active-les d\'abord.' ),
			esc_html( 'Activation impossible' ),
			array( 'back_link' => true )
		);
	}
}

/**
 * Required plugins that are not running.
 *
 * @param string[] $requires Slugs.
 * @return string[] Labels of the missing ones.
 */
function blank_missing_requirements( array $requires ) {
	$labels  = array(
		'blank-core'  => 'Blank Core',
		'woocommerce' => 'WooCommerce',
	);
	$missing = array();
	foreach ( $requires as $slug ) {
		$running = 'woocommerce' === $slug ? class_exists( 'WooCommerce' ) : (bool) apply_filters( 'blank_plugin_running', 'blank-core' === $slug, $slug );
		if ( ! $running ) {
			$missing[] = isset( $labels[ $slug ] ) ? $labels[ $slug ] : $slug;
		}
	}
	return $missing;
}
