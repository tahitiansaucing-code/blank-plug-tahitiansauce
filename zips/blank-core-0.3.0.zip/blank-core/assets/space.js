/* Blank Core: owner space actions. Every action is checked again on the server. */
(function () {
	'use strict';
	var cfg = window.blankSpace || {};
	var status = document.querySelector('.blank-status');

	function say(text, bad) {
		if (!status) return;
		status.textContent = text;
		status.hidden = false;
		status.classList.toggle('is-bad', !!bad);
	}

	function call(path, method, body) {
		return fetch(cfg.root + path, {
			method: method,
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
			body: body ? JSON.stringify(body) : undefined
		}).then(function (res) {
			return res.json().catch(function () { return {}; }).then(function (data) {
				if (!res.ok) throw new Error((data && data.message) || 'Action impossible, réessaie.');
				return data;
			});
		});
	}

	document.addEventListener('click', function (event) {
		var btn = event.target.closest('[data-blank-action]');
		if (!btn) return;
		if (btn.dataset.confirm && !window.confirm(btn.dataset.confirm)) return;
		btn.disabled = true;
		call(btn.dataset.blankAction, btn.dataset.method || 'POST').then(function () {
			say(btn.dataset.done || 'C\'est fait.');
			if (btn.dataset.reload) {
				window.location.reload();
				return;
			}
			if (btn.dataset.remove) {
				var gone = document.querySelector(btn.dataset.remove);
				if (gone) gone.remove();
			} else {
				btn.remove();
			}
		}).catch(function (err) {
			btn.disabled = false;
			say(err.message, true);
		});
	});

	document.addEventListener('change', function (event) {
		var select = event.target.closest('[data-blank-select]');
		if (!select) return;
		var body = {};
		body[select.dataset.field || 'value'] = select.value;
		call(select.dataset.blankSelect, 'POST', body).then(function () {
			say('Enregistré.');
		}).catch(function (err) {
			say(err.message, true);
		});
	});

	document.addEventListener('submit', function (event) {
		var form = event.target.closest('[data-blank-form]');
		if (!form) return;
		event.preventDefault();
		var body = {};
		new FormData(form).forEach(function (value, key) { body[key] = value; });
		call(form.dataset.blankForm, 'POST', body).then(function () {
			say('Enregistré.');
		}).catch(function (err) {
			say(err.message, true);
		});
	});
})();
