/* Blank Core: contact form. */
(function () {
	'use strict';
	var cfg = window.blankContact || {};
	document.addEventListener('submit', function (event) {
		var form = event.target.closest('.blank-contact');
		if (!form) return;
		event.preventDefault();
		var out = form.querySelector('.blank-contact-status');
		var btn = form.querySelector('button[type="submit"]');
		var body = {};
		new FormData(form).forEach(function (value, key) { body[key] = value; });
		btn.disabled = true;
		fetch(cfg.url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(body)
		}).then(function (res) {
			return res.json().catch(function () { return {}; }).then(function (data) {
				if (!res.ok) throw new Error((data && data.message) || 'Envoi impossible, réessaie plus tard.');
				form.reset();
				out.textContent = 'Merci, ton message est bien parti.';
			});
		}).catch(function (err) {
			out.textContent = err.message;
		}).then(function () {
			btn.disabled = false;
		});
	});
})();
