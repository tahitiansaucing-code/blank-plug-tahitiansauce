<?php
/**
 * Removes everything Blank Core created: table, options, rate-limit transients, team roles.
 *
 * @package blank-core
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

require_once __DIR__ . '/includes/roles.php';

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange -- uninstall.
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}blank_contact_messages" );

delete_option( 'blank_settings' );
delete_option( 'blank_theme' );
delete_option( 'blank_core_version' );
delete_transient( 'blank_catalog' );

$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_blank\\_rl\\_%' OR option_name LIKE '\\_transient\\_timeout\\_blank\\_rl\\_%'" );

blank_remove_roles();
